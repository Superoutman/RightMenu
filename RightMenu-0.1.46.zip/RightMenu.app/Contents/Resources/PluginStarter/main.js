globalThis.rightMenuPlugin = Object.freeze({
  run(actionID, input) {
    if (actionID !== "run") {
      throw new Error("Unknown action");
    }
    return { ok: true, input };
  }
});
