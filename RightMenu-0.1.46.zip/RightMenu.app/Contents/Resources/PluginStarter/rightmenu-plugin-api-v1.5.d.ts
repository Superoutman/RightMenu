export type JSONValue =
  | null
  | boolean
  | number
  | string
  | JSONValue[]
  | { [key: string]: JSONValue };

export type FinderActionContext = "selection" | "container";
export type FinderActionLocation = "desktop";

export interface PluginUIContentSize {
  width: number;
  height: number;
}

export interface PluginUIWindowPresentation {
  titleVisibility?: "visible" | "hidden";
  initialContentSize?: PluginUIContentSize;
  minimumContentSize?: PluginUIContentSize;
  miniaturizable?: boolean;
}

export interface PluginManifestDescriptionV1_5 {
  description: string;
  localizedDescriptions?: Record<string, string>;
}

export interface PluginBooleanTitleStateV1_3 {
  capability: string;
  trueTitle: string;
  localizedTrueTitles?: Record<string, string>;
}

export interface PluginPermissionV1_5 {
  capability: string;
  reason: string;
  localizedReasons?: Record<string, string>;
}

export interface PluginActionV1_5 {
  id: string;
  title: string;
  finderContexts?: FinderActionContext[];
  finderLocations?: FinderActionLocation[];
  localizedTitles?: Record<string, string>;
  booleanTitleState?: PluginBooleanTitleStateV1_3;
  requiredCapabilities: string[];
}

export interface PluginUIContributionV1_5 {
  id: string;
  kind: "window" | "panel";
  resource: string;
  title: string;
  windowPresentation?: PluginUIWindowPresentation;
  requiredCapabilities: string[];
}

export interface RightMenuHostV1_5 {
  readonly apiVersion: "1.5";
  call(capability: "ui.flashScreen", request: Record<string, never>): { displayed: true };
  call(
    capability: "desktopItems.toggleVisibility",
    request: Record<string, never>
  ): { hidden: boolean };
  call(capability: string, request: JSONValue): JSONValue;
}

export interface RightMenuPluginV1 {
  run(actionID: string, input: JSONValue): JSONValue;
}

declare global {
  const RightMenu: RightMenuHostV1_5;
  var rightMenuPlugin: RightMenuPluginV1;
}
