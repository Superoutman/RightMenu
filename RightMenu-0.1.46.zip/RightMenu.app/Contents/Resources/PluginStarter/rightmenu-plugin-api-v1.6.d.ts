export type JSONValue =
  | null
  | boolean
  | number
  | string
  | JSONValue[]
  | { [key: string]: JSONValue };

export type FinderActionContext = "selection" | "container";
export type FinderActionLocation = "desktop";

export interface PluginUIContentSize {
  width: number;
  height: number;
}

export interface PluginUIWindowPresentation {
  titleVisibility?: "visible" | "hidden";
  initialContentSize?: PluginUIContentSize;
  minimumContentSize?: PluginUIContentSize;
  miniaturizable?: boolean;
}

export interface PluginManifestDescriptionV1_6 {
  description: string;
  localizedDescriptions?: Record<string, string>;
}

export interface PluginBooleanTitleStateV1_3 {
  capability: string;
  trueTitle: string;
  localizedTrueTitles?: Record<string, string>;
}

export interface PluginPermissionV1_6 {
  capability: string;
  reason: string;
  localizedReasons?: Record<string, string>;
}

export interface PluginActionV1_6 {
  id: string;
  title: string;
  finderContexts?: FinderActionContext[];
  finderLocations?: FinderActionLocation[];
  localizedTitles?: Record<string, string>;
  booleanTitleState?: PluginBooleanTitleStateV1_3;
  requiredCapabilities: string[];
  requiredEntitlements: string[];
}

export interface PluginUIContributionV1_6 {
  id: string;
  kind: "window" | "panel";
  resource: string;
  title: string;
  windowPresentation?: PluginUIWindowPresentation;
  requiredCapabilities: string[];
  requiredEntitlements: string[];
}

export interface PluginUpdateV1_6 {
  feedURL: string;
}

export interface PluginEntitlementV1_6 {
  id: string;
  title: string;
  localizedTitles?: Record<string, string>;
  description: string;
  localizedDescriptions?: Record<string, string>;
  purchaseURL?: string;
  signingKeyIDs: string[];
}

export interface PluginEntitlementSigningKeyV1_6 {
  id: string;
  publicKey: string;
}

export interface RightMenuHostV1_6 {
  readonly apiVersion: "1.6";
  call(capability: "ui.flashScreen", request: Record<string, never>): { displayed: true };
  call(
    capability: "desktopItems.toggleVisibility",
    request: Record<string, never>
  ): { hidden: boolean };
  call(capability: string, request: JSONValue): JSONValue;
}

export interface RightMenuPluginV1 {
  run(actionID: string, input: JSONValue): JSONValue;
}

declare global {
  const RightMenu: RightMenuHostV1_6;
  var rightMenuPlugin: RightMenuPluginV1;
}
